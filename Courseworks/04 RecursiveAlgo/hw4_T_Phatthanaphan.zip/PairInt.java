/* Name-Lastname: Thanapoom Phatthanaphan
 * CWID: 20011296
 * Section: CS 570-PA
 * Subject: Homework 4
 */

package Maze;

public class PairInt {

	private int x;
	private int y;
	
	public PairInt(int x, int y) {
		
		this.x = x;
		this.y = y;
		
	}
	
	public int getX() {
		
		return x;
		
	}
	
	public int getY() {
		
		return y;
		
	}
	
	public void setX(int x) {
		
		this.x = x;
		
	}
	
	public void setY(int y) {
		
		this.y = y;
		
	}
	
	public boolean equals(Object p) {
		
		if(p.getClass().equals(PairInt.class) == false) {
			
			return false;
	    	  
	     }
		
		else {
			
			PairInt pairint = (PairInt) p;
			if (this.x == pairint.x && this.y == pairint.y) {
				
				return true;
				
			}
			
			return false;
			
		}
	}
	
	public String toString() {
		
		String result = "[" + x + "," + y + "]";
		return result;
		
	}
	
	public PairInt copy() {
		
		PairInt solutions = new PairInt(x, y);
		return solutions;
		
	}
}
